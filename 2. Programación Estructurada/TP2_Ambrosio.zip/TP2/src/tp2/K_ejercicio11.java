package tp2;

import java.util.Scanner;
/**
 * @author Ambrosio
 */
public class K_ejercicio11 {

    public static void main(String[] args) {
        /**
         * Cálculo de descuento especial usando variable global. 
         * Declara una variable global Ejemplo de entrada/salida: = 0.10. 
         * Luego, crea un método calcularDescuentoEspecial(double precio) 
         * que use la variable global para calcular el descuento especial del 10%. 
         * Dentro del método, declara una variable local descuentoAplicado, 
         * almacena el valor del descuento y muestra el precio final con descuento.
         */
        
        //Crear objeto input
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        double descuento = 0.10; //Si no va a cambiar podria ser una variable
        double precio;
        
        // Pedir valores al usuario
        System.out.print("Ingrese el precio del producto: ");
        precio= Double.parseDouble(input.nextLine());
        

        //Llamar Metodo
        double descuentoAplicado = calcularDescuentoEspecial(precio, descuento);
        double precioFinal = precio - descuentoAplicado;
        System.out.println("El descuento aplicado tiene un valor de:  "+descuentoAplicado+" $");
        System.out.println("El precio final con descuento es de:  "+(precioFinal)+" $");
    }
    
    public static double calcularDescuentoEspecial(double precio, double descuento){
        double descuentoAplicado= precio* descuento;
        return descuentoAplicado;
    }
  
    
}

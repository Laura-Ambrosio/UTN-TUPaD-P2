package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class H_ejercicio8 {

    public static void main(String[] args) {
        /**
         * *Cálculo del Precio Final con impuesto y descuento. Crea un método
         * calcularPrecioFinal(double impuesto, double descuento) que calcule el
         * precio final de un producto en un e-commerce. La fórmula es:
         * PrecioFinal = PrecioBase + (PrecioBase×Impuesto) −(PrecioBase×Descuento) 
         * PrecioFinal = PrecioBase + (PrecioBase \times Impuesto) - (PrecioBase \times Descuento) 
         * Desde main(), solicita el precio base del producto, el porcentaje de impuesto
         */
        
        //Crear objeto input en la clase scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        double impuesto, descuento, precioBase;
        
        // Pedir valores al usuario
        System.out.print("Ingrese el precio base del producto : ");
        precioBase = Integer.parseInt(input.nextLine());
        System.out.print("Ingrese el porcentaje de impuesto. Ej: 5% > ingrese 5 : ");
        impuesto = Integer.parseInt(input.nextLine());
        System.out.print("Ingrese el porcentaje de descuento. Ej: 5% > ingrese 5 : ");
        descuento = Integer.parseInt(input.nextLine());  

        //Llamar Metodo
        System.out.println("El precio final del articulo ingresado es "+calcularPrecioFinal(impuesto, descuento, precioBase)+"$");
    }
    
    //Crear metodo calcularPrecio Final con impuesto y descuento
    
     public static double calcularPrecioFinal (double impuesto, double descuento, double precioBase) {
         //Convertir porcentaje entero a su expresion decimal
         double impuestoDecimal=impuesto/100;
         double descuentoDecimal=descuento/100;
         //Calcular precioFinal
         double precioFinal=precioBase + (precioBase*(impuestoDecimal)) - (precioBase*descuentoDecimal);
    return (int) precioFinal; //Por que tengo que poner integer ahi??? si todos los valores son double
    
}
     
}



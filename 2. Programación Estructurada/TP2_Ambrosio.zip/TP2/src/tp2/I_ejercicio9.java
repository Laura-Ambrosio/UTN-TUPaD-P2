package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class I_ejercicio9 {

    public static void main(String[] args) {

        //Crear objeto input en Scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        double precioProducto, peso, precioTotal, costoEnvio;
        String zona;
        String nacional = "Nacional";
        String internacional= "Internacional";
        
        //Pedir valores al usuario
       
        System.out.print("Ingrese el precio del producto");
        precioProducto = Double.parseDouble(input.nextLine());
        System.out.print("Ingrese el peso del paquete");
        peso = Double.parseDouble(input.nextLine());
        
        //Asegurarse que solo se puedan ingresar las palabras "Nacional" e "Internacional"      
        
         while(true){     
            System.out.print("Ingrese el tipo de envio > Nacional o Internacional");
            zona= input.nextLine();
            
            if (zona.equals(nacional) || zona.equals(internacional)){
                break;
            }else {
                System.out.println("ERROR: tipo de envio ingresado no valido");
            }
     
         }
        
        //Asegurarse que solo se puedan ingresar las palabras "Nacional" e "Internacional"        
        
        //Llamar al metodo
        costoEnvio = calcularCostoEnvio(peso, zona);
        precioTotal = calcularTotalCompra(precioProducto, peso, zona);
        
        System.out.println("El costo del envio es de "+costoEnvio+"$");
        System.out.println("El total de compra es de: "+precioTotal+"$");
        
    }
    
    public static double calcularCostoEnvio(double peso, String zona) {
        //Declarar varibles
        int precioNacional = 5;
        int precioInternacional = 10;
        double costoEnvio;
        //Calcular segun zona ingresada
        if (zona.equals("Nacional")) {
           costoEnvio=peso*precioNacional;
        }else {
             costoEnvio=peso*precioInternacional;
                }           
        //Devolver costo de envio
        return costoEnvio;
        
    }

    public static double calcularTotalCompra(double precioProducto, double peso, String zona) {
       return precioProducto + calcularCostoEnvio(peso, zona);
        

    }
    
}

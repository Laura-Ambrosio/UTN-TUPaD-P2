package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class G_ejercicio7 {

    public static void main(String[] args) {
        // Escribe un programa que solicite al usuario una nota entre 0 y 10. 
        //Si el usuario ingresa un número fuera de este rango, debe seguir pidiéndole la nota hasta que ingrese un valor válido.
     
        
        //Crear objeto input en clase Scanner
        Scanner input = new Scanner(System.in);

        //Definir variables
        int nota;
        
        //Logica Principal
        
        do {            
            System.out.print("Ingrese una nota entre 0 y 10: ");
            nota = Integer.parseInt(input.nextLine());
        } while (nota <0 || nota > 10);
        
        System.out.println("La nota ingresada es: "+nota);
    }
    
}

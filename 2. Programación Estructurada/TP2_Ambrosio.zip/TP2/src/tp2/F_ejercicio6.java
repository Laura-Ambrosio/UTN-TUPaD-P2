package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class F_ejercicio6 {

    public static void main(String[] args) {
        // Escribe un programa que pida al usuario ingresar 10 números enteros y cuente cuántos son positivos, negativos y cuántos son ceros.
        
        //Definir objeto input en la clase Scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        int num;
        int positivo= 0;
        int negativo= 0;
        int cero = 0;
        
        //Logica principal
        
        for (int i = 1; i < 11; i++) {
            System.out.print("Ingrese los numeros que desea clasificar, num"+i+": ");
            num = Integer.parseInt(input.nextLine());
            
            if (num > 1) {
                positivo += 1;
            } else if (num == 0) {
                cero += 1;  
            }else {
               negativo +=1;
            }

            }
         
        System.out.println("La distribucion de los numeros ingresados fue la siguiente: ");
        System.out.println("Cantidad de numeros positivos: "+positivo);
        System.out.println("Cantidad de numeros negativos: "+negativo);
        System.out.println("Cantida de ceros: "+cero);
        }
      
        
    }
    


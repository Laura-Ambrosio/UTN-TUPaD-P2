package tp2;

import java.util.Scanner;
/**
 * @author Ambrosio
 */
public class B_ejercicio2 {

    public static void main(String[] args) {
        // Pedir tres numeros enteros determinar el mayor
        
        //Definir variables
        int mayor = 0;
        // Crear objeto input 
        Scanner input = new Scanner (System.in);
        
        //Pedir 3 numeros enteros
        for (int i = 1; i < 4; i++) {
            System.out.print("Ingrese un numero entero (num" + i + "): ");
            int num = Integer.parseInt(input.nextLine());
            
            //Guardar el mayor
            if (num > mayor) {
                mayor = num;
            }    
            System.out.println("De los numeros ingresados, el mayor es: " +mayor);
    }
   
}
}
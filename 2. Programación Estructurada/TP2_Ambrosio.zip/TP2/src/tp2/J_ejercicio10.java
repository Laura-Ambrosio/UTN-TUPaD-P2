package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class J_ejercicio10 {

    public static void main(String[] args) {
        /**
         * Actualización de stock a partir de venta y recepción de productos.
         * Crea un método actualizarStock(int stockActual, int cantidadVendida, int cantidadRecibida), 
         * que calcule el nuevo stock después de una venta y recepción de productos: 
         * NuevoStock = StockActual − CantidadVendida + CantidadRecibida 
         * NuevoStock = CantidadVendida + CantidadRecibida 
         * Desde main(), solicita al usuario el stock actual, la cantidad vendida y la cantidad recibida, 
         * y muestra el stock actualizado.
         *
         */
        
        //Crear clase Scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        int stockActual, cantidadVendida, cantidadRecibida;
        
        // Pedir valores al usuario
        System.out.print("Ingrese el stock Actual del producto: ");
        stockActual = Integer.parseInt(input.nextLine());
        System.out.print("Ingrese las unidades de producto vendidas : ");
        cantidadVendida = Integer.parseInt(input.nextLine());
        System.out.print("Ingrese las unidades de producto recibidas : ");
        cantidadRecibida = Integer.parseInt(input.nextLine());  

        //Llamar Metodo
        System.out.println("El nuevo stock contiene "+actualizarStock(stockActual, cantidadVendida, cantidadRecibida)+" unidades del producto solicitado");
        
    }
    
    public static int actualizarStock(int stockActual, int cantidadVendida, int cantidadRecibida){
        int nuevoStock = (stockActual - cantidadVendida) + cantidadRecibida;
        return nuevoStock;
    }
    
}

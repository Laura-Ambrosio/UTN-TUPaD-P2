
package tp2;

public class L_ejercicio12 {

    public static void main(String[] args) {
        /**
         * 12. Modificación de un array de precios y visualización de resultados. 
         * Crea un programa que: 
         * a. Declare e  inicialice un array con los precios de algunos productos. 
         * b. Muestre los valores originales de los precios. 
         * c. Modifique el precio de un producto específico. 
         * d. Muestre los valores modificados.
         *
         * Conceptos Clave Aplicados: 
         * ✔ Uso de arrays (double[]) para almacenar valores. 
         * ✔ Recorrido del array con for-each para mostrar valores. 
         * ✔  Modificación de un valor en un array mediante un índice. 
         * ✔  Reimpresión del array después de la modificación.
         */
         
         //Declarar e iniciar un array con precios de productos
        
        double precios[] = {10.50, 25.50, 33.75, 44.99, 55.55};
        
        //Imprimir precios originales
        imprimirPreciosFor(precios);
        
        //Modifique el precio de un producto
        System.out.println("El precio1 pasara de valer '10.50' a valer '66.66'");
        precios[0]=66.66;
        
        //Imprimir precios actualizados
        imprimirPreciosFor(precios);
      
    }
    
    public static void imprimirPreciosFor(double[] precios) {
        for (int i = 0; i < precios.length; i++) {
            double precio = precios[i];
            System.out.println("Precio"+(i)+": "+precio+"$");     
        }
        
      
    }
    
    
}

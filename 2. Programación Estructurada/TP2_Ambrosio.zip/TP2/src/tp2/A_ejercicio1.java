package tp2;

import java.util.Scanner;

public class A_ejercicio1 {

    public static void main(String[] args) {
        
        //Pedir numero y definir variable
        Scanner input = new Scanner(System.in);
        
        System.out.print("Ingrese un anio para saber si es bisiesto: ");
        int anio_usuario = Integer.parseInt(input.nextLine());

        //Definir logica del programa
 
        if ((anio_usuario % 4 == 0 && anio_usuario % 100 != 0) || anio_usuario%400 == 0) {
            System.out.print("El anio "+anio_usuario+" es bisiesto");
        } 
        else {
            System.out.print("El anio "+anio_usuario+" no es bisiesto");
        }
        
    }
    
}

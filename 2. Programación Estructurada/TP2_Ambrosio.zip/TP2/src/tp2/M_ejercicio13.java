package tp2;
/**
 * @author Ambrosio
 */
public class M_ejercicio13 {

    public static void main(String[] args) {
        /**
         * 13. Impresión recursiva de arrays antes y después de modificar un
         * elemento. Crea un programa que: a. Declare e inicialice un array con
         * los precios de algunos productos. b. Use una función recursiva para
         * mostrar los precios originales. c. Modifique el precio de un producto
         * específico. d. Use otra función recursiva para mostrar los valores
         * modificados.
         *
         */
        
        //Declarar e iniciar un array con precios de productos
        
        double precios[] = {10.50, 25.50, 33.75, 44.99, 55.55};
        
        //Imprimir precios originales
        imprimirPreciosRecur(precios);
        
        //Modifique el precio de un producto
        System.out.println("El precio1 pasara de valer '10.50' a valer '66.66'");
        precios[0]=66.66;
        
        //Imprimir precios actualizados
        imprimirPreciosRecur(precios);
    }
    
    // Método público 
    public static void imprimirPreciosRecur(double[] arr) {
        System.out.println("Precios originales:");
        precios(arr, 0);  // arranca siempre en 0  
    }
    // Método privado, para que el usuario no elija el valor del indice
    private static void precios(double[] arr, int index) {
        if (index == arr.length) {
            return; //fin de la recursion
        }
        
        System.out.println("Precio"+(index+1)+": "+arr[index]+"$");
        precios(arr, index +1);
}
}   


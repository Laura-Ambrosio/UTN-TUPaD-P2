package tp2;

import java.util.Scanner;
/**
 * @author Ambrosio
 */
public class D_ejercicio4 {

    public static final double DESCUENTOA = 0.10;
    public static final double DESCUENTOB= 0.15;
    public static final double DESCUENTOC= 0.20;
    
    
    public static void main(String[] args) {
        /**
         * Calculadora de Descuento según categoría. Escribe un programa que
         * solicite al usuario el precio de un producto y su categoría (A, B o
         * C). Luego, aplique los siguientes descuentos: Categoría A: 10% de
         * descuento Categoría B: 15% de descuento Categoría C: 20% de descuento
         * El programa debe mostrar el precio original, el descuento aplicado y
         * el precio final
         */
        
        //Crear objeto input
        Scanner input = new Scanner(System.in);
       
        //Pedir dato al usuario
        System.out.print("Ingrese el precio del producto:  ");
        double precio = Double.parseDouble(input.nextLine());
       System.out.print("Ingrese la categoria del producto (A, B o C):  ");
        String categoria= (input.nextLine());
        
        //Calcular precio
        double precioDescuentoA = (precio-(precio*DESCUENTOA));
        double precioDescuentoB = (precio-(precio*DESCUENTOB));
        double precioDescuentoC = (precio-(precio*DESCUENTOC));
        
        // Imprimir precio final con descuento o mensaje de error
        switch (categoria) {
            case "A": 
                System.out.print("\n El precio ingresado fue: "+precio);
                System.out.println("\n Luego del descuento el precio es de : "+precioDescuentoA);
                break;
            case "B": 
                System.out.print("\n El precio ingresado fue: "+precio);
                System.out.println("\n Luego del descuento el precio es de : "+precioDescuentoB);
                break;
            case "C": 
                System.out.print("\n El precio ingresado fue: "+precio);
                System.out.println("\n Luego del descuento el precio es de : "+precioDescuentoC);
                break;
            default:
                System.out.println("La Categoria ingresada no es valida");
        }
        
    }
    
}

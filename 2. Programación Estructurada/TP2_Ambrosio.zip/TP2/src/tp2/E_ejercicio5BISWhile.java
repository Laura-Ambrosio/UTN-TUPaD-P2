/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class E_ejercicio5BISWhile {

    public static void main(String[] args) {
        /**
         * Suma de Números Pares (while). 
         * Escribe un programa que solicite números al usuario y sume solo los números pares. 
         * El ciclo debe continuar hasta que el usuario ingrese el número 0, 
         * momento en el que se debe mostrar la suma total de los pares ingresados.
         */
        
        //Crear objeto input dentro de la clase Scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables
        int num = 1;
        int suma = 0;
        
        //Logica principal
        while (num!=0) {       
            System.out.print("Ingrese los numeros que desea sumar: ");
             num = Integer.parseInt(input.nextLine());
            
            if (num%2 == 0) {
                suma = suma + num;               
            }
        System.out.println("La suma de los valores pares ingresados es: "+suma);     
        }

    }
    
}

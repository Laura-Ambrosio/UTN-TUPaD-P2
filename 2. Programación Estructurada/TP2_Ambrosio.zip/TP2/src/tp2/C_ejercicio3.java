package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class C_ejercicio3 {

    public static void main(String[] args) {
        /**
         * solicitar edad y clasificar Menor de 12 años: "Niño" Entre 12 y 17
         * años: "Adolescente" Entre 18 y 59 años: "Adulto" 60 años o más:
         * "Adulto mayor"
         */

        //Solicitar edad
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese su edad: ");
        int edad = Integer.parseInt(input.nextLine());

        if (edad < 12) {
            System.out.println(" Clasificacion segun edad: ninix");
        } else if (edad < 18) {
            System.out.println("Clasificacion segun edad: Adolescente");
        } else if ( edad < 60) {
            System.out.println("Clasificacion segun edad: Adulto");
        } else {
            System.out.println("Clasificacion segun edad: Adulto mayor");
        }

    }

}

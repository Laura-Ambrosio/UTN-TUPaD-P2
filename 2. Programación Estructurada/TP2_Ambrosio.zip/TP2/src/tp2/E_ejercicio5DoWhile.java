package tp2;

import java.util.Scanner;

/**
 * @author Ambrosio
 */
public class E_ejercicio5DoWhile {

    public static void main(String[] args) {
        /**
         * Solicitar números al usuario hasta que ingrese el numero 0
         * Sumar los numeros pares ingresados
         * Al finalizar mostrar la suma total
         */
        
        //Definir objeto input en la clase Scanner
        Scanner input = new Scanner(System.in);
        
        //Definir variables 
        int suma = 0;
        int num;
        //Solicitar numeros mientras sean distintos a 0
        
        do {
            System.out.print("Ingrese los numeros que quiera sumar y presione 0 para detener el programa");
            num = Integer.parseInt(input.nextLine());
            if (num % 2 == 0) {
                suma = suma +  num;
            }
        } while (num != 0);
        
        System.out.println("La suma de los numeros pares ingresados es: "+suma);

        
    }
    
}
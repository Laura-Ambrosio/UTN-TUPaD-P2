/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajopractico_1;

/**
 *
 * @author Laura Ambrosio
 */
public class ejercicio_6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String nombre = "Juan Perez";
         String direccion = "Calle Falsa 123";
         int edad = 30;
         
        System.out.println("Nombre: "+ nombre +"\n");
        System.out.println("Dirección: "+ direccion +"\n");
        System.out.println("Edad:  "+ edad +"\n");
   
    }
    }
    
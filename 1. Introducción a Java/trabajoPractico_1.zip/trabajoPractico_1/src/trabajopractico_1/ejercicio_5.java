/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package trabajopractico_1;

import java.util.Scanner;

/**
 *
 * @author Laura Ambrosio
 */
public class ejercicio_5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
        int entero1, entero2;
       
        System.out.print("Ingrese el primer número entero: ");
        entero1=Integer.parseInt(input.nextLine()) ;
        
        System.out.print("Ingrese el primer número entero: ");
        entero2=Integer.parseInt(input.nextLine()) ; 
       
        System.out.println(entero1+" + " + entero2+ " = " + (entero1 + entero2));
        System.out.println(entero1+" - " + entero2+ " = " + (entero1 - entero2));
        System.out.println(entero1+" * " + entero2+ " = " + (entero1* entero2));
        System.out.println(entero1+" / " + entero2+ " = " + ( (double) entero1 / entero2));
    
    }
    
}

package Interfaces.PagoConDescuento;

import Interfaces.Pedido.Pedido;


public class PayPal implements PagoConDescuento{
    private double descuentoAplicado = 0.0;
    

      //Metodos
    @Override
    public void aplicarDescuento(double descuento) {
        this.descuentoAplicado = descuento;
    }

    @Override
    public void procesarPago(double monto) {
        // Aplica el descuento al monto recibido
        double montoFinal = monto * (1 - descuentoAplicado);
        System.out.println("Procesando pago con PayPal: $" + montoFinal);

    }
}
    
    
  
    

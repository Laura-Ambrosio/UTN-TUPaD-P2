package Interfaces.PagoConDescuento;

public interface Pago {
    

  //Metodo abstracto procesarPago  
    public void procesarPago (double monto);
    
}

package Interfaces.PagoConDescuento;

public class TarjetaCredito implements PagoConDescuento {
    private String numeroTarjeta;
    private String titular;
    private double descuentoAplicado = 0.0;
    
    //Constructor
    public TarjetaCredito(String numeroTarjeta, String titular) {
        this.numeroTarjeta = numeroTarjeta;
        this.titular = titular;
    }
    
    @Override
    public void aplicarDescuento(double descuento) {
        this.descuentoAplicado = descuento;
    }
    
    @Override
    public void procesarPago(double monto) {
        double montoFinal = monto * (1 - descuentoAplicado);
        System.out.println("Procesando pago con Tarjeta de Credito: $" + montoFinal);
    }
    
    //Getters y Setters
    public String getNumeroTarjeta() {
        return numeroTarjeta;
    }
    
    public void setNumeroTarjeta(String numeroTarjeta) {
        this.numeroTarjeta = numeroTarjeta;
    }
    
    public String getTitular() {
        return titular;
    }
    
    public void setTitular(String titular) {
        this.titular = titular;
    }
}
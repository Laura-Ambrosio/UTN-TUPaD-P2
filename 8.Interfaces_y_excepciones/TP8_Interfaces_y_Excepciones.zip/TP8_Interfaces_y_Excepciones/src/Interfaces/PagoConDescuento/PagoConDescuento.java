package Interfaces.PagoConDescuento;

public interface PagoConDescuento extends Pago{
    
    
//Metodos
    
public void aplicarDescuento(double descuento);    
      
    
}

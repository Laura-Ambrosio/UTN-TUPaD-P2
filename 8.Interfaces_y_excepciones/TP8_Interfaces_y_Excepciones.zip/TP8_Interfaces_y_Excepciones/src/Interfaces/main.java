package Interfaces;

import Interfaces.Notificar.Cliente;
import Interfaces.PagoConDescuento.PagoConDescuento;
import Interfaces.PagoConDescuento.PayPal;
import Interfaces.PagoConDescuento.TarjetaCredito;
import Interfaces.Pedido.Pedido;
import Interfaces.Pedido.Producto;

public class main {

    public static void main(String[] args) {

//Crear Cliente
        Cliente cliente = new Cliente("Juan", "juan@gmail.com");

//Crear Pedido
        Pedido pedido = new Pedido(cliente);

//Crear productos y agregarlos a pedido
        pedido.agregarProducto(new Producto("Laptop", 1000.0));
        pedido.agregarProducto(new Producto("Mouse", 50.0));
        pedido.agregarProducto(new Producto("Teclado Mecánico", 150.00));

//Mostrar total
        System.out.println("Total del pedido: $" + pedido.calcularTotal());
        System.out.println();

//Pagar con PayPal (15% descuento)
        System.out.println("--- Pago con PayPal ---");
        PagoConDescuento paypal = new PayPal();
        
        pedido.procesarPago(paypal, 0.15);

        System.out.println("------------------------------------------------");

//Pagar con tarjeta (otro pedido)
        Pedido pedido2 = new Pedido(cliente);
        pedido2.agregarProducto(new Producto("Monitor", 350.00));
        pedido2.agregarProducto(new Producto("Webcam", 80.00));

        System.out.println("Total del pedido 2: $" + pedido2.calcularTotal());
        System.out.println();

//Pagar con Tarjeta (25% descuento)
        System.out.println("--- Pago con Tarjeta de Crédito ---");
        PagoConDescuento tarjeta = new TarjetaCredito("4532-1234-5678-9012", "Juan Tome");
        pedido2.procesarPago(tarjeta, 0.25);
    }
}


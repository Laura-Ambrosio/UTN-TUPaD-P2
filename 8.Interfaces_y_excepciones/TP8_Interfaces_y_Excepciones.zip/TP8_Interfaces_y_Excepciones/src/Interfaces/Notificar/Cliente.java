package Interfaces.Notificar;

public class Cliente implements Notificable {
    private String nombre;
    private String email;
    
    //Constructor
    public Cliente(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }
    
    //Método heredado de Notificable
    @Override
    public void notificarPago() {
        System.out.println("Cliente: " + nombre);
        System.out.println("Email: " + email);
        System.out.println("Su pedido ha sido procesado exitosamente");
    }
    
    //Getters
    public String getNombre() {
        return nombre;
    }
    
    public String getEmail() {
        return email;
    }
    
    //Setters
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
}

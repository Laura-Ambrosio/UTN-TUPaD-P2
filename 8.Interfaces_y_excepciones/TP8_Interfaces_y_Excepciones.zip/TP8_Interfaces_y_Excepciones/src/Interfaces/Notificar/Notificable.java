package Interfaces.Notificar;

public interface Notificable {
   
    
    //Metodo para cambio de estado
    public void notificarPago();
    
}

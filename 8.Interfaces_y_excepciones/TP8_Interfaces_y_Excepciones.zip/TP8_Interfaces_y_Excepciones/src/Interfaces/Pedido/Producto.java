package Interfaces.Pedido;

public class Producto implements Pagable {
    private String nombre;
    private double precio;
    
    //Constructor
    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }
    
    //El precio que va a usar pedido
    @Override
    public double calcularTotal() {
        return precio; 
    }
    
    //getters
    public String getNombre() {
        return nombre;
    }
    
    public double getPrecio() {
        return precio;
    }
}
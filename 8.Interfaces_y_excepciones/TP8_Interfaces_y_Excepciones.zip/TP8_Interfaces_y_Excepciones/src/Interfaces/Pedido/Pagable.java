package Interfaces.Pedido;

public interface Pagable {
    

    
    //Metodo pagable
    
    public double calcularTotal();
    
}

package Interfaces.Pedido;

import Interfaces.Notificar.Cliente;
import Interfaces.PagoConDescuento.PagoConDescuento;
import java.util.ArrayList;
import java.util.List;

public class Pedido implements Pagable {
     private List<Producto> productos = new ArrayList<>();
     private Cliente cliente;
     private String estado = "PENDIENTE";
     
//Constructor    
    public Pedido(Cliente cliente) {
        this.cliente = cliente;
    }
     
     //Agregar Producto
    public void agregarProducto(Producto producto){
        productos.add(producto);
    }
     
    //Calcular total del pedido
    @Override
    public double calcularTotal() {
        double total = 0.0;
        for (Producto producto : productos) {
            total += producto.calcularTotal(); //Usa el calcularTotal de producto que devuelve precio 
        }
        return total;
    }
    
   //Procesar el pedido, ver si hay descuento
    
 public void procesarPago(PagoConDescuento metodoPago, double descuento) {
        //Calcular total
        double total = calcularTotal();        
        //Aplicar descuento al método de pago
        metodoPago.aplicarDescuento(descuento);  //El valor de dto que le pasa a procesarPago     
        //Procesar el pago
        metodoPago.procesarPago(total); //El descuento calculado en el metodo de pago
        
        //Cambiar estado y notificar
        this.estado = "PAGADO";
        cliente.notificarPago();
    }
 
 
 
}  
    
       //Debe notificar el cambio de estado (supongo que de pagado a no pagado)
    
    
    

    
    
    
  

package Excepciones;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //Ejecutar Metodos
        System.out.println("--- 1. División segura ---");
        divisionSegura(scanner);
        
        System.out.println("--- 2. Conversión de cadena a número ---");
        conversionCadena(scanner);
        
        System.out.println("--- 3. Lectura de archivo ---");
        lecturaArchivo();
        
        System.out.println("--- 4. Excepción personalizada ---");
        validarEdad(scanner);
        
        System.out.println("--- 5. try-with-resources ---");
        leerConTryWithResources();
        
        scanner.close();
    }
    
    //Metodos
    //1. División segura
    public static void divisionSegura(Scanner scanner) {
        try {
            System.out.print("Ingrese el dividendo: ");
            int dividendo = scanner.nextInt();
            System.out.print("Ingrese el divisor: ");
            int divisor = scanner.nextInt();
            
            int resultado = dividendo / divisor;
            System.out.println("Resultado: " + resultado);
            
        } catch (ArithmeticException e) {
            System.out.println("Error: No se puede dividir entre cero");
        }
    }
    
    //2. Conversión de cadena a número
    public static void conversionCadena(Scanner scanner) {
        try {
            System.out.print("Ingrese un número: ");
            scanner.nextLine(); // Limpiar buffer
            String texto = scanner.nextLine();
            
            int numero = Integer.parseInt(texto);
            System.out.println("Número convertido: " + numero);
            
        } catch (NumberFormatException e) {
            System.out.println("Error: El texto ingresado no es un número válido");
        }
    }
    
    //3. Lectura de archivo > hay que indicar que el archivo debe cerrarse
    public static void lecturaArchivo() {
        try {
            FileReader archivo = new FileReader("src/Excepciones/archivo.txt");
            BufferedReader lector = new BufferedReader(archivo);
            String linea;
            
            System.out.println("--------------Contenido del archivo----------");
            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
            }
            
            lector.close();
            archivo.close();
            
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: El archivo no existe");
        } catch (IOException e) {
            System.out.println("ERROR al leer el archivo");
        }
    }
    
    //4. Validación de edad con excepción personalizada
    public static void validarEdad(Scanner scanner) {
        try {
            System.out.print("Ingrese su edad: ");
            int edad = scanner.nextInt();
            
            if (edad < 0 || edad > 120) {
                throw new EdadInvalidaException("La edad debe estar entre 0 y 120");
            }
            
            System.out.println("Edad válida: " + edad + " años");
            
        } catch (EdadInvalidaException e) {
            System.out.println("ERROR " + e.getMessage());
        }
    }
    
    //5. Try-with-resources > cierra automaticamente
    public static void leerConTryWithResources() {
        try (BufferedReader lector = new BufferedReader(new FileReader("src/Excepciones/archivo.txt"))) {
            
            String linea;
            System.out.println("Contenido del archivo (con try-with-resources):");
            while ((linea = lector.readLine()) != null) {
                System.out.println(linea);
            }
            
        } catch (FileNotFoundException e) {
            System.out.println("Error: El archivo no existe");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo");
        }
    }
}
package tp6colecciones.Actividad2;

public class Autor {
    private String id;
    private String nombre;
    private String nacionalidad;

//Constructor 

 public Autor(String id, String nombre, String nacionalidad) {
        this.id = id;
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
    }
    

//Metodos

public void mostrarInfoAutor() {
    System.out.println("----------- Información del Autor ------------");
    System.out.println("ID: " + getId());
    System.out.println("Nombre: " + getNombre());
    System.out.println("Nacionalidad: " + getNacionalidad());
}

//Getters para metodo mostrar
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
        
        
        
    //Final      
    }
}


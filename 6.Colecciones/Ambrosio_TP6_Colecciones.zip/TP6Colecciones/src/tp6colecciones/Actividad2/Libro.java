package tp6colecciones.Actividad2;

public class Libro {
    private String isbn;
    private String titulo;
    private int anioPublicacion;
    private Autor autor; //Relacion de asociacion 1:1
    
//Constructor > No tiene porque se construye en Biblioteca

public Libro(String isbn, String titulo, int anioPublicacion, Autor autor) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
        this.autor = autor;
}

//Metodos
    public void mostrarInfoLibro() {
        System.out.println("------ Información del Libro -------");
        System.out.println("Título: " + titulo);
        System.out.println("ISBN: " + isbn);
        System.out.println("Año de publicación: " + anioPublicacion);
        System.out.println("Autor:");
        autor.mostrarInfoAutor(); // llama al método mostrar del autor
    }
    
//Getter
    public String getIsbn() {
        return isbn;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public Autor getAutor() {
        return autor;
    }



    
}
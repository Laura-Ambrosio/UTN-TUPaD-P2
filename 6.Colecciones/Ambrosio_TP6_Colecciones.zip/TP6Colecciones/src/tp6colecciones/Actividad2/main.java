package tp6colecciones.Actividad2;

public class main {

    public static void main(String[] args) {

//1. Creamos una biblioteca.

Biblioteca terror = new Biblioteca("Terror en Alejandría");

//2. Crear al menos tres autores

Autor autor1 = new Autor("A001", "Stephen King", "Estados Unidos");
Autor autor2 = new Autor("A002", "Mariana Enriquez", "Argentina");
Autor autor3 = new Autor("A003", "Shirley Jackson", "Estados Unidos");

//3. Agregar 5 libros asociados a alguno de los Autores a la biblioteca.

terror.agregarLibro("ISBN001", "It", 1986, autor1);
terror.agregarLibro("ISBN002", "El Resplandor", 1977, autor1);

terror.agregarLibro("ISBN003", "Las cosas que perdimos en el fuego", 2016, autor2);
terror.agregarLibro("ISBN004", "Nuestra parte de noche", 2019, autor2);

terror.agregarLibro("ISBN005", "Siempre hemos vivido en el castillo", 1962, autor3);
terror.agregarLibro("ISBN006", "La lotería", 1948, autor3);

//4. Listar todos los libros con su información y la del autor.
System.out.println("/////////////////////////////////////////////////////////////////////////////");
terror.listarLibros();

//5. Buscar un libro por su ISBN y mostrar su información.
System.out.println("///////////////////////  Caso:  ISBN EXISTE  ///////////////////////////////");
terror.buscarLibroPorIsbn("ISBN006");
System.out.println("/////////////////////// Caso:  ISBN NO EXISTE  ///////////////////////////////");
terror.buscarLibroPorIsbn("ISBN011");

//6. Filtrar y mostrar los libros publicados en un año específico.
System.out.println("///////////////Caso:  año EXISTE ////////////////////");
terror.filtrarLibrosPorAnio(1948);
System.out.println("///////////////Caso:  año NO EXISTE ////////////////////");
terror.filtrarLibrosPorAnio(1943);

//7. Eliminar un libro por su ISBN y listar los libros restantes.
System.out.println("/////////////////////////////////////////////////////////////////////////////");
terror.eliminarLibro("ISBN001");

//8. Mostrar la cantidad total de libros en la biblioteca.
System.out.println("/////////////////////////////////////////////////////////////////////////////");
terror.mostrarCantidadLibros();

//9. Listar todos los autores de los libros disp
System.out.println("/////////////////////////////////////////////////////////////////////////////");
terror.mostrarAutoresDisponibles();
        

        
//Final 
    }
    
}

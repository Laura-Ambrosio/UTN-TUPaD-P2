package tp6colecciones.Actividad2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Biblioteca {
   private String nombre;
   private List<Libro> libros = new ArrayList<>();
    
//Constructor

    public Biblioteca(String nombre) {
        this.nombre = nombre;
    }
// Metodos
// Agregar libro a biblioteca       
public void agregarLibro(String isbn, String titulo,int anioPublicacion, Autor autor){
    libros.add(new Libro(isbn, titulo, anioPublicacion, autor));
    
}

//Listar Libros con informacion incluyendo autor        
public void listarLibros(){
        for (Libro libro : libros) {
       libro.mostrarInfoLibro();     
        }
    }

// Buscar libro por ISBN (usando Iterator)
private Libro libroPorIsbn(String isbn) {
    Libro libroEncontrado = null;
    Iterator<Libro> it = this.libros.iterator();
    
    while (it.hasNext() && libroEncontrado == null) { 
        Libro l = it.next(); 
        if (l.getIsbn().equalsIgnoreCase(isbn)) { // compara si el ISBN coincide
            libroEncontrado = l; 
        }
    }
    return libroEncontrado; // devuelve el libro encontrado o null si no lo encontró > lo puede usar otro metodo
}

//Buscar y Mostrar Libros con informacion incluyendo autor   
public void buscarLibroPorIsbn(String isbn) {
    Libro libro = libroPorIsbn(isbn);  // usa el método que devuelve el libro
    if (libro != null) {
        libro.mostrarInfoLibro();      // muestra la información del libro y su autor
    } else {
        System.out.println("No se encontró ningún libro con el ISBN: " + isbn);
    }
}
       
// Eliminar libro por ISBN y mostrar los libros restantes
public void eliminarLibro(String isbn) {
    Libro libro = libroPorIsbn(isbn); // busca el libro por ISBN

    if (libro != null) {
        System.out.println("Se eliminó el libro: " + libro.getTitulo());
        libros.remove(libro);       // elimina el libro de la lista
        
        System.out.println("Libros restantes en la biblioteca:");
        listarLibros();             // muestra los libros restantes
        
    } else {
        System.out.println("No se encontró ningún libro con el ISBN: " + isbn);
    }
}

//Obtener cantidad de libros

// Mostrar la cantidad total de libros en la biblioteca
public void mostrarCantidadLibros() {
    System.out.println("Cantidad total de libros en la biblioteca \"" + nombre + "\": " + libros.size());
}


//Filtrar libros por año y mostrar
public void filtrarLibrosPorAnio(int anio) {
    boolean libroEncontrado = false;

    for (Libro libro : libros) {
        if (libro.getAnioPublicacion() == anio) {
            libro.mostrarInfoLibro();
            libroEncontrado = true;
        }
    }

    if (!libroEncontrado) {
        System.out.println("No se encontraron libros publicados en el año " + anio);
    }
}

//Mostrar Autores Disponibles
public void mostrarAutoresDisponibles(){
    Set<Autor> autores = new HashSet<>(); //Para que no se repitan los autores

    for (Libro libro : libros) {  //Busco los autores des los libros que estan en la biblioteca y los agrego al set
        autores.add(libro.getAutor());
    }

    System.out.println("Autores disponibles en la biblioteca \"" + nombre + "\":");
    for (Autor autor : autores) { //itero sobre los autores del set y veo su informacion
        autor.mostrarInfoAutor();
    }
}




        //Final   
    }


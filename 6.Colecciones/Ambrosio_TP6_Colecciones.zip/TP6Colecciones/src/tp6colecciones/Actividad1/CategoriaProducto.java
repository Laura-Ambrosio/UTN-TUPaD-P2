package tp6colecciones.Actividad1;

public enum CategoriaProducto {
    
    //Son objetos/instancias constantes del tipo CategoriaProducto
    ALIMENTOS("Productos comestibles"),
    ELECTRONICA("Dispositivos electrónicos"),
    ROPA("Prendas de vestir"),
    HOGAR("Artículos para el hogar");
    
    //Crea un campo interno para guardar el texto
    private final String descripcion;
    
    //El constructor del enum es privado por defecto (y no pacakge-private)
    CategoriaProducto(String descripcion) {
        this.descripcion = descripcion;
}
    
    //Obtener informacion de la categoria del producto
    public String getDescripcion() {
        return descripcion;
    
    }
    
    
}

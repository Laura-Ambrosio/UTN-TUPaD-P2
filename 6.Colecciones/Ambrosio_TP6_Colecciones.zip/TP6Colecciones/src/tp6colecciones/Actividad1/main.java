package tp6colecciones.Actividad1;

import static tp6colecciones.Actividad1.CategoriaProducto.*; //Importo todas las categorias de productos

public class main {

    public static void main(String[] args) {
        /**
         * Se debe desarrollar un sistema de stock que permita gestionar
         * productos en una tienda, controlando su disponibilidad, precios y
         * categorías. La información se modelará utilizando clases, colecciones
         * dinámicas y enumeraciones en Java.
        *
         */

        // Crear Inventario
        Inventario supermercado = new Inventario();

        // 1. Crear al menos cinco productos con diferentes categorías y agregarlos al inventario.
        Producto calabaza = new Producto("1", "Calabaza", 1500.5, 8, ALIMENTOS);
        Producto manzana = new Producto("2", "Manzana", 500.0, 10, ALIMENTOS);
        Producto pan = new Producto("3", "Pan Integral", 250.0, 15, ALIMENTOS);

        Producto celular = new Producto("4", "Smartphone", 25000.0, 5, CategoriaProducto.ELECTRONICA);
        Producto notebook = new Producto("5", "Notebook", 55000.0, 3, CategoriaProducto.ELECTRONICA);
        Producto auriculares = new Producto("6", "Auriculares", 3000.0, 8, CategoriaProducto.ELECTRONICA);

        Producto remera = new Producto("7", "Remera", 3500.0, 20, CategoriaProducto.ROPA);
        Producto pantalon = new Producto("8", "Pantalón", 6500.0, 12, CategoriaProducto.ROPA);
        Producto campera = new Producto("9", "Campera", 45000.0, 6, CategoriaProducto.ROPA);

        Producto lampara = new Producto("10", "Lámpara de mesa", 1500.0, 7, CategoriaProducto.HOGAR);
        Producto silla = new Producto("11", "Silla de comedor", 3200.0, 4, CategoriaProducto.HOGAR);
        Producto olla = new Producto("12", "Olla a presión", 2800.0, 5, CategoriaProducto.HOGAR);

        // Agregar los objetos al inventario
        supermercado.agregarProducto(calabaza);
        supermercado.agregarProducto(manzana);
        supermercado.agregarProducto(pan);

        supermercado.agregarProducto(celular);
        supermercado.agregarProducto(notebook);
        supermercado.agregarProducto(auriculares);

        supermercado.agregarProducto(remera);
        supermercado.agregarProducto(pantalon);
        supermercado.agregarProducto(campera);

        supermercado.agregarProducto(lampara);
        supermercado.agregarProducto(silla);
        supermercado.agregarProducto(olla);
        
        
        // 2. Listar todos los productos mostrando su información y categoría.
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Lista de Productos """);
        supermercado.listarProductos();
        
        // 3. Buscar un producto por ID y mostrar su información.
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Caso: La id existe """);       
        supermercado.mostrarProductoPorId("1"); 
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Caso: La id NO existe """);     
         supermercado.mostrarProductoPorId("20"); 
         
         // 4. Filtrar y mostrar productos que pertenezcan a una categoría específica.
         System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Filtrar por categoria  """);     
         supermercado.filtrarProdPorCategoria(CategoriaProducto.ALIMENTOS);
         
         // 5. Eliminar un producto por su ID y listar los productos restantes.
                  System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Eliminar y listar  """);   
         supermercado.eliminarProducto("1");
         

         // 6. Actualizar el stock de un producto existente.
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Caso: La id existe (Antes de Actualizar) """);
        supermercado.mostrarProductoPorId("2"); 
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                            Despues de Actualizar) """); 
        supermercado.actualizarStock("2", 100); 
        supermercado.mostrarProductoPorId("2"); 
        System.out.println("""
                            ////////////////////////////////////////////////////////////////////////////////////////////////
                           Caso: La id NO existe """);     
         supermercado.actualizarStock("20", 100); 
         supermercado.mostrarProductoPorId("20"); 
         
         // 7. Mostrar el total de stock disponible.
         System.out.println("/////////////////////////////////////////////////////////////////////////////");
         supermercado.obtenerTotalStock();
         
         // 8. Obtener y mostrar el producto con mayor stock.
         System.out.println("/////////////////////////////////////////////////////////////////////////////");
         supermercado.obtenerProductoConMayorStock();
         
         // 9. Filtrar productos con precios entre $1000 y $3000.
         System.out.println("/////////////////////////////////////////////////////////////////////////////");
         supermercado.filtrarProductosPorPrecio(3000, 5000);
         
         // 10. Mostrar las categorías disponibles con sus descripciones.
         System.out.println("/////////////////////////////////////////////////////////////////////////////");
         supermercado.mostrarCategoriasDisponibles();
         
         
         
         
         
         
    }
}

package tp6colecciones.Actividad1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Inventario {
    private List<Producto> productos = new ArrayList<>(); //"productos" es el nombre de la lista de objetos 

//Construir el inventario
    public Inventario() {
    }
    
//Agregar productos al inventario
    public void agregarProducto(Producto prod) {  // "prods" representa un objeto producto
        if (prod != null && !productos.contains(prod)) { // Si el objeto existe (not null) y no esta en la lista
            productos.add(prod); //agregarlo
        }
}
    
// Mostrar la informacion del producto
    public void listarProductos() {
        for (Producto prod : productos) {
        prod.mostrarInfoProd();     
        }
    }
    
 
// Buscar producto por ID (usando Iterator)
private Producto buscarProductoPorId(String id) {
    Producto prodEncontrado = null;
    Iterator<Producto> it = this.productos.iterator();
    
    while (it.hasNext() && prodEncontrado == null) { // mientras haya productos y no se haya encontrado
        Producto p = it.next(); //devuelve el proximo elemento en la iteracion
        if (p.getId().equalsIgnoreCase(id)) { // //Compara si la id de p es igual a la id buscada
            prodEncontrado = p; // guarda el producto encontrado y hace te termine el ciclo
        }
    }
    return prodEncontrado; // devuelve el valor del producto encontrado o null si no lo encontro
}

//Busca y muestra el producto segun su id
public void mostrarProductoPorId(String id){
    Producto prod = buscarProductoPorId(id);  
    if (prod != null ) {
    prod.mostrarInfoProd();
}else {
   System.out.println("No se encontro el ID " + id);   
    }
}  
         
//Filtrar y mostrar productos que pertenezcan a una categoría específica.
    public void filtrarProdPorCategoria(CategoriaProducto categoria){
        boolean categoriaEncontrada = false;
        System.out.println("Productos de  la categoría: " + categoria);
        
        for (Producto prod : productos) {
            if (prod.getCategoria() == categoria){   
            prod.mostrarInfoProd();
            categoriaEncontrada = true;
            }
        }
        if (!categoriaEncontrada) { // Si es falso
        System.out.println("No se encontraron productos en la categoría: " + categoria);
    } 
}
    
    // Eliminar por Id y listar los restantes
    
   public void eliminarProducto (String id) {
       Producto prod = buscarProductoPorId(id);
        if (prod != null) {
            if (prod.getId().equalsIgnoreCase(id)){
                System.out.println("Se elimino el producto: " + prod.getNombre());
                productos.remove(prod);
                System.out.println("Productos restantes en el inventario:");
                listarProductos();                
            }else {
            System.out.println("No se encontro el producto con id : " + id);
        }
   } 
   }
   
    //Actualizar stock de un producto existente
    
   public void actualizarStock (String id, int nuevaCantidad) {
       Producto prod = buscarProductoPorId(id);
        if (prod != null) {
            if (prod.getId().equalsIgnoreCase(id)){
                prod.setCantidad(nuevaCantidad);
            }
        }else {
            System.out.println("No se encontro el producto con id : " + id);
        }
   }
  
   // 7. Mostrar el total de stock disponible.
   public void obtenerTotalStock() {
       int totalStock = 0;
         for (Producto prod : productos) {
             totalStock += prod.getCantidad();
         }
         System.out.println("El stock total es: " + totalStock);
   }
       
   // 8. Obtener y mostrar el producto con mayor stock.
   
   public void obtenerProductoConMayorStock(){
       int mayorStock = 0;
       String mayorStockProd = " ";
         for (Producto prod : productos) {
             if(prod.getCantidad() >mayorStock) {
                 mayorStock = prod.getCantidad();
                 mayorStockProd = prod.getNombre();
             }
         }
         System.out.println("El producto con mayor stock es : " + mayorStockProd + " Stock: " + mayorStock);
   }
       
   // 9. Filtrar productos con precios entre $1000 y $3000.
   
   public void filtrarProductosPorPrecio(double min, double max) {
        System.out.println("Productos con precio entre " + min + " y " + max);
        for (Producto prod : productos) {
            if (prod.getPrecio() > min && prod.getPrecio() < max) {
                System.out.println(prod.getNombre() + " $" + prod.getPrecio());
            }
            
       }
   }
   
   // 10. Mostrar las categorías disponibles con sus descripciones.
   
public void mostrarCategoriasDisponibles() {
    System.out.println("Categorías disponibles:");

    for (CategoriaProducto categoria : CategoriaProducto.values()) {
        System.out.println("- " + categoria.name() + ": " + categoria.getDescripcion());
    }
}
}
   
   
  
              
        
       
   
    

    
    
  

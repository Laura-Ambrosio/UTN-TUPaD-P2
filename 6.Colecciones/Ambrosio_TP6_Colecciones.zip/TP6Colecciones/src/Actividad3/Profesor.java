package Actividad3;

import java.util.ArrayList;
import java.util.List;

public class Profesor {
    private String id;
    private String nombre;
    private String especialidad;
    private List<Curso> cursos = new ArrayList<>();

    
//Constructor    
    public Profesor(String id, String nombre, String especialidad) {
        this.id = id;
        this.nombre = nombre;
        this.especialidad = especialidad;
    }

    // Agregar curso si no existe y sincronizar del lado del curso
    public void agregarCurso(Curso curso) {
        if (!cursos.contains(curso)) { //Si no esta en la lista de cursos del profesor
            cursos.add(curso); //agrega al curso a la lista de cursos del profesor
        }
        if (curso.getProfesor() != this) { //si el profesor que ejecuta el metodo es distinto al que ya esta asociado a ese curso
            curso.setProfesor(this); // sincroniza el lado del curso > le asigna un profesor al curso
        }
    }

    // Eliminar curso y sincronizar del lado del curso
    public void eliminarCurso(Curso curso) {
        if (cursos.contains(curso)) {
            cursos.remove(curso);
        }
        if (curso.getProfesor() == this) {
            curso.setProfesor(null); // dejar profesor en null
        }
    }

   //Mostrar codigos y nobres
    public void listarCursos() {
            System.out.println("Cursos de " + nombre + ":");
            for (Curso curso : cursos) {
                System.out.println(" - " + curso.getCodigo() + ": " + curso.getNombre());
            }
    }

    // Datos del profesor y cantidad de cursos
    public void mostrarInfo() {
        System.out.println("-------------------------");
        System.out.println("ID: " + id);
        System.out.println("Nombre: " + nombre);
        System.out.println("Especialidad: " + especialidad);
        System.out.println("Cantidad de cursos: " + cursos.size());
        System.out.println("-------------------------");
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Curso> getCursos() {
        return cursos;
    }
}

    
    


package Actividad3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Universidad {
    private String nombre;
    private List<Profesor> profesores = new ArrayList<>();
    private List<Curso> cursos = new ArrayList<>();

    //Constructor
    public Universidad(String nombre) {
        this.nombre = nombre;
    }

    //Agregar Profesor a la universidad si no existe
    public void agregarProfesor(Profesor prof) {
        if (!profesores.contains( prof)) {
            profesores.add( prof);
        }
    }

    //Agregar curso a la universidad si no existe
    public void agregarCurso(Curso curso) {
        if (!cursos.contains(curso)) {
            cursos.add(curso);
        }
    }

// Buscar profesor por ID (usando Iterator)
private Profesor profesorPorId(String id) {
    Profesor profEncontrado = null;
    Iterator<Profesor> it = this.profesores.iterator();

    while (it.hasNext() && profEncontrado == null) { 
        Profesor prof = it.next(); 
        if (prof.getId().equalsIgnoreCase(id)) { // compara si el id coincide
            profEncontrado = prof; 
        }
    }
    return profEncontrado; 
}

// Busca y muestra el profesor según su ID
public void BuscarProfesorPorId(String id){
    Profesor prof = profesorPorId(id);
    if (prof != null) {
        prof.mostrarInfo();
    } else {
        System.out.println("No se encontró el profesor con ID: " + id);
    }
}

//Buscar curso por código (usando Iterator)
private Curso cursoPorCodigo(String codigo) {
    Curso cursoEncontrado = null;
    Iterator<Curso> it = this.cursos.iterator();

    while (it.hasNext() && cursoEncontrado == null) { 
        Curso curso = it.next(); 
        if (curso.getCodigo().equalsIgnoreCase(codigo)) { // compara si el código coincide
            cursoEncontrado = curso; 
        }
    }
    return cursoEncontrado; // devuelve el curso encontrado o null si no lo encontró
}

// Busca y muestra el curso según su código
public void BuscarCursoPorCodigo(String codigo){
    Curso curso = cursoPorCodigo(codigo);
    if (curso != null) {
        curso.mostrarInfo();
    } else {
        System.out.println("No se encontró el curso con código: " + codigo);
    }
}

    //Asignar un profesor a un cruso usando el metodo setProfesor
    public void asignarProfesorACurso(String codigoCurso, String idProfesor) {
        
        Curso curso = cursoPorCodigo(codigoCurso); //busca y devuelve el curso
        Profesor profesor = profesorPorId(idProfesor); //busca y devuelve el profesor
        
        if (curso != null && profesor != null) { //si ambos existen
            curso.setProfesor(profesor); //ejecuta el metodo set profesor para agregar/cambiar un profesor
        }
    }

    //Listar Profesores
    public void listarProfesores() {
        for (Profesor  prof : profesores) {
             prof.mostrarInfo();
             prof.listarCursos();
        }
    }
    
   //Listar Cursos
    public void listarCursos() {
        for (Curso curso : cursos) {
            curso.mostrarInfo();
        }
    }
    
  //Eliminar un curso usando su codigo
    public void eliminarCurso(String codigo) {
        Curso curso = cursoPorCodigo(codigo);
        if (curso != null) {
            if (curso.getProfesor() != null) {
                curso.getProfesor().getCursos().remove(curso); // eliminar de profesor
            }
            cursos.remove(curso); // eliminar de universidad
            System.out.println("Curso " + codigo + " eliminado.");
        }
    }

    //Eliminar un profesor usando su id
    public void eliminarProfesor(String id) {
        Profesor profesor = profesorPorId(id);
        if (profesor != null) {
            // dejar null en todos sus cursos
            for (Curso curso : profesor.getCursos()) {
                curso.setProfesor(null);
            }
            profesores.remove(profesor);
            System.out.println("Profesor " + id + " eliminado.");
        }
    }
    
    // getter para el reporte
    
    public List<Profesor> getProfesores() {
        return profesores;
}

    
}

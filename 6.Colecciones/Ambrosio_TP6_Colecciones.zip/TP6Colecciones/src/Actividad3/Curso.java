package Actividad3;

public class Curso {
    private String codigo;
    private String nombre;
    private Profesor profesor;

    
    //Constructor 
    public Curso(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    // Asignar/cambiar profesor y sincronizar ambos lados
    public void setProfesor(Profesor prof) {
        if (this.profesor != null && this.profesor !=  prof) { //si ya tengo un profesor asignado y es distinto que el que le estoy pasando
            
            this.profesor.getCursos().remove(this); //elimino el curso de la lista del profesor original
        }
        this.profesor =  prof; //el nuevo profesor ahora es el que le pase
        
        if ( prof != null && ! prof.getCursos().contains(this)) { //si el profesor que paso no es null y no tiene este (this) curso en su lista
             prof.getCursos().add(this); // agregar a la lista de cursos del nuevo profesor
        }
    }

    //Mostrar informacion del curso
public void mostrarInfo() {
    System.out.println("-------------------------");
    System.out.println("Código: " + codigo);
    System.out.println("Nombre: " + nombre);
    // Si no tienen profesor asignado muestra "sin profesor"
    if (profesor != null) {
        System.out.println("Profesor: " + profesor.getNombre());
    } else {
        System.out.println("Profesor: Sin profesor");
    }
}


    // Getters
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public Profesor getProfesor() {
        return profesor;
    }
}

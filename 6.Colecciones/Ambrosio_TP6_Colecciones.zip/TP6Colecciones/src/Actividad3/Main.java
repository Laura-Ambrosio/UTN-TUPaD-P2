package Actividad3;

public class Main {

    public static void main(String[] args) {

        // Crear Universidad
        Universidad unrc = new Universidad("Universidad Nacional de Rio Cuarto");

        // 1. Crear al menos 3 profesores
        Profesor prof1 = new Profesor("P001", "Juan Pérez", "Matemáticas");
        Profesor prof2 = new Profesor("P002", "María López", "Historia");
        Profesor prof3 = new Profesor("P003", "Carlos Gómez", "Literatura");

        // 2. Crear 5 cursos
        Curso curso1 = new Curso("C001", "Álgebra");
        Curso curso2 = new Curso("C002", "Cálculo");
        Curso curso3 = new Curso("C003", "Historia de América");
        Curso curso4 = new Curso("C004", "Literatura Moderna");
        Curso curso5 = new Curso("C005", "Filosofía");

        // 3. Agregar profesores y cursos a la universidad
        unrc.agregarProfesor(prof1);
        unrc.agregarProfesor(prof2);
        unrc.agregarProfesor(prof3);

        unrc.agregarCurso(curso1);
        unrc.agregarCurso(curso2);
        unrc.agregarCurso(curso3);
        unrc.agregarCurso(curso4);
        unrc.agregarCurso(curso5);

        // 4. Asignar profesores a cursos usando asignarProfesorACurso
        unrc.asignarProfesorACurso("C001", "P001");
        unrc.asignarProfesorACurso("C002", "P001");
        unrc.asignarProfesorACurso("C003", "P002");
        unrc.asignarProfesorACurso("C004", "P003");
        unrc.asignarProfesorACurso("C005", "P003");

        // 5. Listar cursos con su profesor
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Listado de cursos con su profesor:");
        unrc.listarCursos();

        // Listar profesores con sus cursos
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Listado de profesores con sus cursos:");
        unrc.listarProfesores();

        // 6. Cambiar el profesor de un curso y verificar sincronización
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Cambio profesor P002 del curso C003 ");
        unrc.asignarProfesorACurso("C003", "P003"); //le asigno el prof 3 en lugar del 1
        unrc.BuscarCursoPorCodigo("C003");
        unrc.BuscarProfesorPorId("P002"); // Ver si curso se removió de su lista
        unrc.BuscarProfesorPorId("P003");

        // 7. Remover un curso y confirmar
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Remover curso C003");
        unrc.eliminarCurso("C003");
        unrc.listarCursos();
        unrc.BuscarProfesorPorId("P002");

        // 8. Remover un profesor y dejar profesor = null en sus cursos
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Eliminar profesor P001");
        unrc.eliminarProfesor("P001");
        unrc.listarProfesores();
        unrc.BuscarCursoPorCodigo("C001"); // Verifico que el curso quedó sin profesor
        unrc.BuscarCursoPorCodigo("C002");

        // 9. Mostrar un reporte: cantidad de cursos por profesor
        System.out.println("////////////////////////////////////////////////////////////////////////////////");
        System.out.println("Reporte: cantidad de cursos por profesor");

        for (Profesor prof : unrc.getProfesores()) { // recorremos todos los profesores
            System.out.println(prof.getNombre() + ": " + prof.getCursos().size() + " curso(s)");
        }

    }
}


    


package tp3_introduccion_a_poo;

public class NaveEspacial {
    private String nombre;
    private int combustible;
    
    public void despegar() {
        combustible = 50;
    }
    
    public void avanzar(int distancia) {
        if(distancia <= combustible && (distancia > 0)){
            combustible-= distancia;
        }
    }
    
    public void  recargarCombustible(int cantidad) {
        if(cantidad > 0 && (combustible+cantidad <= 50)){
            combustible+=cantidad;
        }
    }
    
    public void mostrarEstado() {
                System.out.println(" \nNombre de la nave " + nombre+ "\n"
                + "Combustible " + combustible);
    }
    
    
}

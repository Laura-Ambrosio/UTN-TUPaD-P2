package tp3_introduccion_a_poo;

/**
 * @author Ambrosio
 */
public class ejercicio1_registroEstudiante {


    public static void main(String[] args) {
        //Instanciar estudiante
        RegistroEstudiante est1 = new RegistroEstudiante();
        
        //Mostrar informacion, vacio
       est1.mostrarInfo();
        
       //Agregar informacion
       est1.setNombre("Laura");
       est1.setApellido("Ambrosio");
       est1.setCurso("1-7");
       est1.setCalificacion(9);
       
       //Bajar Calificacion
       est1.bajarCalificacion(5);
       est1.mostrarInfo();
       
       //Subir Calificacion
       est1.subirCalificacion(3);
       est1.mostrarInfo();
        
        
    }
    
}

package tp3_introduccion_a_poo;

public class ejercicio5_SimulacionNaveEspacial {

    public static void main(String[] args) {
        // Reglas: Validar que haya suficiente combustible antes de avanzar y evitar que se supere el límite al recargar.
        //Tarea: Crear una nave con 50 unidades de combustible,
        // intentar avanzar sin recargar,
        // luego recargar y avanzar correctamente 
        //   Mostrar el estado al final

    //Crear Nave
    NaveEspacial saocom = new NaveEspacial();
    
    //Despegar > asigna 50 unidaes de combustible
    saocom.despegar();
    
    //Avanzar sin recargar
    saocom.avanzar(5);
    saocom.mostrarEstado();
            
    saocom.avanzar(15);
    saocom.mostrarEstado();
    
    //Recargar
    saocom.recargarCombustible(50);
    saocom.mostrarEstado();
    
    saocom.recargarCombustible(20);
    saocom.mostrarEstado();
   
    

    }

}

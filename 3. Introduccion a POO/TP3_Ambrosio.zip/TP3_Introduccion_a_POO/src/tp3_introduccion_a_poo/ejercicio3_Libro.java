package tp3_introduccion_a_poo;

public class ejercicio3_Libro {

    public static void main(String[] args) {
        
        //Crear un libro
        
        Libro libro1= new Libro();
        
        //Consigna: Intentar modificar el año con un valor inválido y luego con uno válido, mostrar la información final.
        
        //Mostrar informacion inicial
        libro1.mostrarLibro();
        
        //Valor invalido negativo
        libro1.setAnioPublicacion(-5);
        
        //Valor valido positivo
        libro1.setAnioPublicacion(1989);
        
        //Mostrar Informacion final
        libro1.mostrarLibro();
        
        
    }
    
}

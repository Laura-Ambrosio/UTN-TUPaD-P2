package tp3_introduccion_a_poo;

public class ejercicio4_GestionGallinas {

    public static void main(String[] args) {

        //Crear dos gallinas
        GestionGallinas turuleca1 = new GestionGallinas();
        GestionGallinas turuleca2 = new GestionGallinas();

        //Poner huevos
        
        //Set idGallina

        turuleca1.setIdGallina(01);
        turuleca2.setIdGallina(02);
        
        //anio 1
        turuleca1.ponerHuevo(65);
        turuleca2.ponerHuevo(84);
        
        turuleca1.mostrarEstado();
        turuleca2.mostrarEstado();

        
        //anio 2
        turuleca1.ponerHuevo(35);
        turuleca2.ponerHuevo(66);
        turuleca1.mostrarEstado();
        turuleca2.mostrarEstado();
        
        //Edad Gallinas
        
        turuleca1.envejecer(2023, 2025);
        turuleca2.envejecer(2022, 2025);
        
        turuleca1.mostrarEstado();
        turuleca2.mostrarEstado();
        
        

    }

}

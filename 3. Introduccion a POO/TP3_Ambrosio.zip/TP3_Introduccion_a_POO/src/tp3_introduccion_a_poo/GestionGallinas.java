package tp3_introduccion_a_poo;

public class GestionGallinas {
    
    private int idGallina;
    private int edad;
    private int huevosPuestos;
    
    
    //Calcula edad de la gallina
    public void envejecer(int anioNac, int anioActual) {
            if((anioNac <= anioActual) & (anioNac > 0  & anioActual> 0)) {
            edad = anioActual - anioNac;
    }
    }
    
    //Huevos puestos en el dia
    public void ponerHuevo(int huevos) {
        if (huevos > 0) {
        //Calcularl total de huevos
        huevosPuestos+=huevos;
    }
    }
    
    //Definir informacion de la identidad

    public void setIdGallina(int nuevaIdGallina) {
        if (nuevaIdGallina > 0) {
        idGallina = nuevaIdGallina;
    }
    }
    
    //Mostrar Informacion de la gallina
    public void mostrarEstado() {
        System.out.println(" \nNumero identificatorio: " + idGallina+ "\n"
                + "Edad: " + edad + "\n"
                + "Total de huevos puestos:  " + huevosPuestos);
   }
   
    
    
}

package tp3_introduccion_a_poo;

/**
 * @author Ambrosio
 */
public class ejercicio2_registroMascota {

    public static void main(String[] args) {
        
    RegistroMascota m1 = new RegistroMascota();
    
    //Mostrar informacion de la mascota en el anio actual
   
    m1.mostrarInfo();
    System.out.println("");
    
    m1.setNombre("Pochoclo");
    m1.setEspecie("Perro");
    m1.cumplirAnios(2020, 2025);
    
    m1.mostrarInfo();
    

    }
        
    }
    


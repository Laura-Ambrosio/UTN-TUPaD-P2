package tp3_introduccion_a_poo;

/**
 * @author Ambrosio
 */
public class RegistroEstudiante {
    
        private String nombre;
        private String apellido;
        private String curso;
        private int calificacion;
        
        public void setNombre(String nuevoNombre) {
            if(nuevoNombre != null) {
                nombre = nuevoNombre;
                System.out.println(" \nINFO: nombre actualizado. Nombre: "+nuevoNombre);
            } else {
                System.out.println(" \nERROR: Ingrese un nombre");
            }
        }
        
        
         public void setApellido(String nuevoApellido) {
            if (nuevoApellido != null) {
             apellido = nuevoApellido;
            System.out.println(" \nINFO: apellido actualizado. Apellido: "+nuevoApellido);
            } else{
                System.out.println(" \nERROR: Ingrese un apellido");
            }   
         }
          public void setCurso(String nuevoCurso) {
            if (nuevoCurso != null) {
            curso = nuevoCurso;
            System.out.println(" \nINFO: curso actualizado. Curso: "+nuevoCurso);
            }else {
                System.out.println(" \nERROR: Ingrese un curso");
            }     
        }
          
         public void setCalificacion(int nuevaCalificacion) {
             if(nuevaCalificacion > 1 || nuevaCalificacion < 10) {
            calificacion = nuevaCalificacion;
            System.out.println(" \nINFO: calificacion actualizada. Calificacion "+nuevaCalificacion);
             } else {
                System.out.println(" \nERROR: Ingrese una calificacion valida (del 1 al 10)");
             }
        }
         
        public void mostrarInfo() {
                System.out.println(" \nNombre y Apellido: "+ nombre + " " + apellido + "\n" +
                                              "Curso: " + curso + "\n" +
                                              "Calificacion: "+calificacion);    
        }
        
        public void subirCalificacion(int puntos) {
            if ((calificacion + puntos < 11)){
                calificacion  += puntos;
                System.out.println(" \nINFO: La calificacion subio. OK");
            } else {
                System.out.println(" \nERROR: La calificacion final no puede ser mayor a 10");
            }
        }
        
        public void bajarCalificacion(int puntos) {
            if ((calificacion -puntos > 0)){
                calificacion  -= puntos;
                System.out.println(" \nINFO: Calificacion bajo. OK\n");
            }else {
                System.out.println(" \nERROR: La calificacion final no puede ser menor a 1");
            }
        }
}

package tp3_introduccion_a_poo;

public class RegistroMascota {

    private String nombre;
    private String especie;
    private int edad;
    
//Recibe un nombre y valida el dato
    public void setNombre(String nuevoNombre) {
            if(nuevoNombre != null) {
                nombre = nuevoNombre;
        }
    }
    
    //Recibe una especie y valida el dato
    public void setEspecie(String nuevaEspecie) {
        if (nuevaEspecie != null) {
            especie= nuevaEspecie;
        }
    }

    //Recibe anio de nac y anio actual, valida los datos y calcula la edad
    public void cumplirAnios(int anioNac, int anioActual) {
        if (anioNac <=  anioActual) {
             edad= anioActual-anioNac;
        }
    }
 
    public void mostrarInfo() {
        System.out.println(" \nNombre: " + nombre + "\n"
                + "Especie: " + especie + "\n"
                + "Edad: " + edad);   
}
}
    


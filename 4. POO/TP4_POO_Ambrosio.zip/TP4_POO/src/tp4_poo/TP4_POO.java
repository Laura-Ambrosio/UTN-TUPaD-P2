
package tp4_poo;

public class TP4_POO {

    public static void main(String[] args) {
        
/**Instancie varios objetos usando ambos constructores.
Aplique los métodos actualizarSalario() sobre distintos empleados.
Imprima la información de cada empleado con toString().
Muestre el total de empleados creados con mostrarTotalEmpleados().
**/

Empleado emp1 = new Empleado(1, "Jose", "Empleado", 1000);
Empleado emp2 = new Empleado("Patricia", "Vicepresidente");
Empleado emp3 = new Empleado("Ivana", "Contadora");

//Valor de salario inicial
System.out.println(emp1.toString());
System.out.println(emp2.toString());
System.out.println(emp3.toString());
System.out.println("");

//Aumento salarial
emp1.actualizarSalario(30);
emp2.actualizarSalario(100.0);
emp3.actualizarSalario(15);

//Salario luego de los aumentos
System.out.println(emp1.toString());
System.out.println(emp2.toString());
System.out.println(emp3.toString());

Empleado.mostrarTotalEmpleados();


    }
    
}

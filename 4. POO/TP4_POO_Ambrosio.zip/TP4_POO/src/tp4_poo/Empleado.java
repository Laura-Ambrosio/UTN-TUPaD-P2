package tp4_poo;

public class Empleado {
    //Modelar una clase Empleado que represente a un trabajador en una empresa
    //Debe contener constructores y metodos sobrecargados
    //Atributos y metodos estaticos para llevar control de los objetos creados
    
    private int id;  //Para el constructor que requiere todos los parametros como externos
    private String nombre;
    private String puesto;
    private double salario;
    static int totalEmpleados = 0; //Contador global de empleados creados

    
//2. Constructor que recibe todos los atributos como parametro
//Puedo atributos estaticos???
public Empleado(int id, String nombre, String puesto, double salario ) {
    totalEmpleados+=1;
    this.nombre = nombre;
    this.puesto = puesto;
    this.salario = salario;
    this.id = id;
}
    

//2. Constructor que recibe solo nombre y puesto
//El id se asigna automaticamente y el salario es por defecto    
  public Empleado(String nombre, String puesto) {
    totalEmpleados+=1;
    this.nombre = nombre;
    this.puesto = puesto;
    salario = 3000;
    id = totalEmpleados;  
}
    
  
 //3. Recibe un porcentaje de aumento
   public double actualizarSalario(int porcentaje) {
       if(porcentaje >= 0) {
           salario = salario + (salario * porcentaje/100);
       }
       return salario;
   }
   
   
  //3. Recibe una cantidad fija a aumentar
   public double actualizarSalario(double aumento) {
        if(aumento >= 0) {
          salario = salario + aumento;
       }
       return salario;
   }
  
   
   //5. mostrarTotalEmpleados
   public static void mostrarTotalEmpleados() {
        System.out.println("Se crearon un total de "+ totalEmpleados+ " empleados");
    }
   
   
    //4. Metodo toString()
    @Override
    public String toString() {
        return "Empleado{id ="+ id + ", nombre=" + nombre + ", puesto=" + puesto + ", salario=" + salario + "}";
    }
    
 
}

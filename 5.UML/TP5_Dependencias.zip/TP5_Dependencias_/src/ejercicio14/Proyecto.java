package Ejercicio14;

public class Proyecto {
    private String nombre;
    private int duracionMin;
    
//Constructor

    public Proyecto(String nombre, int duracionMin) {
        this.nombre = nombre;
        this.duracionMin = duracionMin;
    }

//Getters para setProyecto

    public String getNombre() {
        return nombre;
    }

    public int getDuracionMin() {
        return duracionMin;
    }
 
    
    
    
    
    
    
}

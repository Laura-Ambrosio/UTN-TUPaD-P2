package Ejercicio14;

public class Render {
    private String formato;
    private Proyecto proyecto;

    //Constructor
    public Render(String formato) {
        this.formato = formato;
    }
    
    //Setear el proyecto a renderizar

    public void setProyecto(Proyecto proyecto) {
        this.proyecto = proyecto;
    }
    
   
    
    
    
    
    
    
    
}

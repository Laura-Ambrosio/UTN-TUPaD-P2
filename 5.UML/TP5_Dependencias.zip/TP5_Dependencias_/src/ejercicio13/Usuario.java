package Ejercicio13;

public class Usuario {
    private String nombre;
    private String email;

    //Constructor Usuario
    public Usuario(String nombre, String email) {
        this.nombre = nombre;
        this.email = email;
    }

    
//Getters para imprimir los setters del codigo QR
    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }
    
    
    
    
}

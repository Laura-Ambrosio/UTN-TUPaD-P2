package Ejercicio11;

//Constructor por default
public class Reproductor {
    
//Reproduce el titulo de la cancion en la instanciaCancion seleccionada
    public void reproducir(Cancion cancion) {
        System.out.println(">>>>>>Reproduciendo cancion <<<<<<\n" + cancion.getTitulo());
    }
    
    
    
}

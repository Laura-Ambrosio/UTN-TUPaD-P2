package Relacion1_1.ejerecicio_1;

import java.time.LocalDate;

public class main1 {

    public static void main(String[] args) {
        //Crea el pasaporte 1
        Pasaporte pas1 = new Pasaporte("AA123456", LocalDate.of(2025, 9, 24), "imagen2", "jpg");
        //Crea el titular 1
        Titular titular1 = new Titular("Juan Perez", 341123456);
        
       pas1.mostrarInfoPasaporte();
        
        //Le asigna un objeto titular a pasaporte (el titular1)
        //Asigna a titular1 el objeto pas1 como pasaporte
        pas1.setTitular(titular1);
        
        pas1.mostrarInfoPasaporte();


    }

}

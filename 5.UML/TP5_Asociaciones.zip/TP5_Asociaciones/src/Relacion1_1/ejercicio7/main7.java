package Relacion1_1.ejercicio7;

public class main7 {

    public static void main(String[] args) {
        // a. Agregación: Vehículo → Motor
        //b. Asociación bidireccional: Vehículo ↔ Conductor
 
        //Instanciar un objeto de cada clase
       
        Vehiculo auto1 = new Vehiculo ("ABC123", "Kangoo", "Nafta", "AZ9731");
        Conductor cond1 = new Conductor("Cristian Beccaria", "AB35987123");
        
        //Mostrar datos de auto
        auto1.mostrarInfoAuto();
        
        //Setear Conductor en un vehiculo
        auto1.setConductor(cond1); 
        
        //Mostrar datos de Reserva
        auto1.mostrarInfoAuto();
        
        
        
    }
    
}

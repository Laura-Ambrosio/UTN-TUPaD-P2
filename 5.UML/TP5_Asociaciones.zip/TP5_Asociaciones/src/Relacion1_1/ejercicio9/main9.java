package Relacion1_1.ejercicio9;

import java.time.LocalDate;
import java.time.LocalTime;

public class main9 {

    public static void main(String[] args) {
        // Cita Medica asociacion directa con Profesional y Paciente
        
        //Instanciar
        Paciente paciente1 = new Paciente("Marisa Lonta", "Osprera");
        Profesional profesional1 = new Profesional("Jorgelina Gonzales" , "Cardiologia");
        CitaMedica turno1 = new CitaMedica(LocalDate.of(2025,10,17), LocalTime.of(9,30,00));
        
        //Mostrar Informacion (parcial) del turno 
        turno1.mostrarInfoCita();
        
        //Asociar Paciente a la cita
        turno1.setPaciente(paciente1);
        
        //Asociar Profesional a la cita
        turno1.setProfesional(profesional1);
        
        //Mostrar Informacion (final) del turno
        turno1.mostrarInfoCita();
        
        
    }
    
}

package Relacion1_1.ejercicio5;

public class main5 {

    public static void main(String[] args) {
      
        //Asociacion bidireccional:Computadora - Propietario
        //Composicion: Computadora - PlacaMadre
        
        Computadora pc1 = new Computadora("Acer", "X5729Y", "C5HRH LA-H501P Rev 1A ", "Intel HM570");
        Propietario prop1 = new Propietario("Marcela Gauna", "37892354");
        
        //Mostrar la informacion de la computadora de acuerdo al propietario
       pc1.mostrarInfoComputadora();
        
        //Setear una computadora para un propietario
        prop1.setComputadora(pc1);
       

         //Mostrar la informacion de la computadora de acuerdo al propietario
         pc1.mostrarInfoComputadora();
        

    }
    
}

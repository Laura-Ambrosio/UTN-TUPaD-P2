package Relacion1_1.ejercicio5;

public class PlacaMadre {
    private String modelo;
    private String chipset;
    
 //Generar constructor con los atributos necesarios   

    public PlacaMadre(String modelo, String chipset) {
        this.modelo = modelo;
        this.chipset = chipset;
    }

 //Getters para luego imprimir informacion

    public String getModelo() {
        return modelo;
    }

    public String getChipset() {
        return chipset;
    }

    
    
    
    
    
}




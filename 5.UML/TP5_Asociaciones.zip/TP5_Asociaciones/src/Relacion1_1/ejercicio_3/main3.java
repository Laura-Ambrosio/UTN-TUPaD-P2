package Relacion1_1.ejercicio_3;

public class main3 {

    public static void main(String[] args) {
        // Asociacion unidireccional: Libro Autor
        // Agregacion: Libro Editorial
        
        //Instanciar un objeto de cada clase
        
         //Instancio Editorial antes de libro ya que lo necesito para construir a libro
        Editorial ed1 = new Editorial("Editorial Futurock", "Una Calle en Buenos Aires");
        
        //Crear el libro con los datos del objeto editorial
        Libro lib1 = new Libro("Donde Mueren las Mariposas", "isbn4567", ed1);
        Autor aut1 = new Autor("Belen Longo", "Argentina");
        
        //Mostrar datos de libro
        
        lib1.mostrarInfoLibro();
        
        //Seter el autor para libro
        lib1.setAutor(aut1); 
        
        //Mostrar informacion final de libro
        lib1.mostrarInfoLibro();
    }
    
}

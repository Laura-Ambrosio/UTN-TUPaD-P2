package Relacion1_1.ejercicio_2;

public class main2 {

    public static void main(String[] args) {
        // Asociacion Bidireccional Celular-usuario
        //Agregacion  Celular- bateria
    
    Bateria bat1 =new Bateria("VG89", "3000") ;
    Celular cel1 = new Celular("781939932000", "Nokia", "Y2255", bat1); //Pasar valor de bateria al instanciar (Agregacion)
    Usuario user1= new Usuario("Juana Perez", "359876542");
    
    cel1.mostrarInfoCelular();    
    
     //set usario en celular (Asociacion bidireccional)
    user1.setCelular(cel1);
    
    
    cel1.mostrarInfoCelular();
    
    
    
    //"[a-zA-Z]+"  Significa uno o más caracteres que sean letras (mayúsculas o minúsculas).]
    // "[a-zA-Z ]+" Permite espacios, por ejemplo entre nombres
    //"\\p{L}+"  Significa cualquier letra en cualquier idioma (incluye letras acentuadas, ñ, etc.)
    //"\\p{L }+" Permite los espacios
    }
}

package Actividad1_herenciaBasica;

public class Auto extends Vehiculo{
    private int cantidadPuertas;
    
//Constructor

    public Auto(int cantidadPuertas, String marca, String modelo) {
        super(marca, modelo);
        this.cantidadPuertas = cantidadPuertas;
    }
      
//Metodos > sobrescribe mostrarInfo

@Override   
public void mostrarInfo() {
    super.mostrarInfo();
    System.out.println("Cantidad de Puertas: " + cantidadPuertas);
}
    
}

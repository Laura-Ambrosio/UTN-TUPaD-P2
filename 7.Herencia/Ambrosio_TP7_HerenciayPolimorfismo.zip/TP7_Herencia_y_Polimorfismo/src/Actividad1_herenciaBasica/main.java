package Actividad1_herenciaBasica;

public class main {


    public static void main(String[] args) {

    Vehiculo v1 = new Vehiculo("Renault", "12");  
    Auto a1 = new Auto(3, "Renault", "Twingo");
        
      a1.mostrarInfo();
        
        
    }
    
}
  
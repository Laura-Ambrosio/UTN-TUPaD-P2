package Actividad1_herenciaBasica;

public class Vehiculo {
    private String marca;
    private String modelo;
    
//Constructor
    public Vehiculo(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }
    
//Metodos
public void mostrarInfo(){
    System.out.println("Marca: " + marca + " Modelo: " + modelo);
}
 
    
}



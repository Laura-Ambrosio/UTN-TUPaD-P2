package Actividad3_Polimorfismo;

public abstract class Empleado {
    private String nombre;
//Constructor

    public Empleado(String nombre) {
        this.nombre = nombre;
    }
   
//Metodo
public abstract double calcularSueldo();    

//Getters
public String getNombre() {
        return nombre;
    }
    
    
}

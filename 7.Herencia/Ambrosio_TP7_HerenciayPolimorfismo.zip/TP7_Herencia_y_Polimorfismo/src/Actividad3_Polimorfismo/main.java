package Actividad3_Polimorfismo;

import java.util.ArrayList;

public class main {

    public static void main(String[] args) {
        //Tarea: Crear lista de empleados, 

        ArrayList<Empleado> empleados = new ArrayList<>();

        empleados.add(new EmpleadoPlanta(15000, "Laura"));
        empleados.add(new EmpleadoPlanta(23000, "Luis"));
        empleados.add(new EmpleadoTemporal(12000, "Lorena"));
        empleados.add(new EmpleadoTemporal(13000, "Lautaro"));

        //Invocar calcularSueldo() polimórficamente
        for (Empleado emp : empleados) {
            System.out.println("Nombre: " + emp.getNombre());
            System.out.println("Sueldo: " + emp.calcularSueldo());

            //Usar instanceof para clasificar
            if (emp instanceof EmpleadoPlanta) {
                System.out.println("Tipo: Planta");
                
            } else if (emp instanceof EmpleadoTemporal) {
                System.out.println("Tipo: Temporal");
            }

            System.out.println("----------------------");
        }
    }
}





package Actividad3_Polimorfismo;

public class EmpleadoPlanta extends Empleado {
    private double salarioAnual;
    
  //Constructor
public EmpleadoPlanta(double salarioAnual, String nombre) {
            super(nombre);
            this.salarioAnual = salarioAnual;
        }

//Metodo    
@Override
    public double calcularSueldo() {
        double salarioMensual = salarioAnual/12;
        return salarioMensual;
    }   
    
    
}

package Actividad3_Polimorfismo;


public class EmpleadoTemporal extends Empleado{
    private double salarioAnual;

  //Constructor
    public EmpleadoTemporal(double salarioAnual, String nombre) {
        super(nombre);
        this.salarioAnual = salarioAnual;
    }

 //Metodo 
  @Override
    public double calcularSueldo() {
        double salarioMensual = salarioAnual/12;
        return salarioMensual;
    }   
    
    
}

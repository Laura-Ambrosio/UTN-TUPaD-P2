package Actividad2_metodosAbstractos;

public class Rectangulo extends Figura{
    private double base;
    private double altura;
    
//Constructor

    public Rectangulo(double base, double altura, String nombre) {
        super(nombre);
        this.base = base;
        this.altura = altura;
    }

//Metodo   
    @Override
    public double calcularArea(){ //base * altura
        double areaRectangulo = this.getBase()* this.getAltura();
        return areaRectangulo;
        
    }
    
    //getter

    public double getBase() {
        return base;
    }

    public double getAltura() {
        return altura;
    }


    
    
}

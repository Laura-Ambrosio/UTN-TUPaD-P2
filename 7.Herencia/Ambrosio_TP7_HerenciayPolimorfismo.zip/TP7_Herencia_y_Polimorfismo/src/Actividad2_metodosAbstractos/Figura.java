package Actividad2_metodosAbstractos;

public abstract class Figura {
    private String nombre;
    
//Constructor
    public Figura(String nombre) {
        this.nombre = nombre;
    }
    
 //Metodos
    public abstract double calcularArea();
 

    }
    
    

    
    
    
    
    


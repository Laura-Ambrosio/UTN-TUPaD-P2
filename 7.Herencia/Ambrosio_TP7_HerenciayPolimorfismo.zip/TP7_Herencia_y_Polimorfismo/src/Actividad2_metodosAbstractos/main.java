package Actividad2_metodosAbstractos;

import java.util.ArrayList;


public class main {

    public static void main(String[] args) {
    // Tarea: Crear un array de figuras y mostrar el área de cada una usando polimorfismo
   
   ArrayList<Figura> figuras = new ArrayList<>();
   
    figuras.add(new Rectangulo(12, 3.5, "Rectangulo 1"));
    figuras.add(new Rectangulo(3.5, 4.5, "Rectangulo 2"));
    figuras.add(new Circulo(4.23, "Circulo 1"));
    figuras.add(new Circulo(2, "Circulo 1"));
    
    for(Figura figura: figuras){
        System.out.println(figura.calcularArea());
    }
        
        
        
        
        
        
        
        
        
        
        
  
    }
    
}

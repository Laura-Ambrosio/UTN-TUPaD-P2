package Actividad2_metodosAbstractos;

public class Circulo extends Figura{
    private double radio;
    
//Constructor

    public Circulo(double radio, String nombre) {
        super(nombre);
        this.radio = radio;
    }

//Metodo   
    @Override
    public double calcularArea(){ //pi*radio al cuadrado
        double areaCirculo = Math.PI * Math.pow(this.getRadio(), 2);
        return areaCirculo;
        
    }

    public double getRadio() {
        return radio;
    }
    
    
    
    
    
}

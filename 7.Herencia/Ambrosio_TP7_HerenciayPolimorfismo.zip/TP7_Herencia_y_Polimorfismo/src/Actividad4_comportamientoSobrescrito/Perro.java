package Actividad4_comportamientoSobrescrito;

public class Perro extends Animal {
    
    
//Constructor    
    public Perro(String tipo) {
        super(tipo);
    }
    
//Sobrescribir el metodo "hacerSonido"
    @Override
    public void hacerSonido() {
        System.out.println("¡Guau Guau!");
    }
}


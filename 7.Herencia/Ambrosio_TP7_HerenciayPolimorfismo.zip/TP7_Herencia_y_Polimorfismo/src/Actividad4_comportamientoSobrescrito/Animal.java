package Actividad4_comportamientoSobrescrito;

public class Animal {
    private String tipo;

    //Constructor
    public Animal(String  tipo) {
        this. tipo =  tipo;
    }

    //Getters
    public String getNombre() {
        return  tipo;
    }

    //Metodo 1
    public void hacerSonido() {
        System.out.println("Sonido de animal");
    }
    
//Metodo 2
    public void describirAnimal() {
        System.out.println("Tipo de animal:  " + tipo);
    }
}


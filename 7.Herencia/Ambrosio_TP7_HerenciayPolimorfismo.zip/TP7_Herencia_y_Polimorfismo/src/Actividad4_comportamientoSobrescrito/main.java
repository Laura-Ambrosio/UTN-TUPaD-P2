package Actividad4_comportamientoSobrescrito;

import java.util.ArrayList;

public class main {
    public static void main(String[] args) {
        //Tarea: Crear lista de animales y mostrar sus sonidos con polimorfismo
        
        ArrayList<Animal> animales = new ArrayList<>();

        animales.add(new Perro("Perro"));
        animales.add(new Gato("Gato"));
        animales.add(new Vaca("Vaca"));
        animales.add(new Perro("Milo"));
        animales.add(new Gato("Gato"));
        animales.add(new Vaca("Vaca"));

        for (Animal animal : animales) {
            // Método de la clase padre
            animal.describirAnimal();  
            // Usa la version sobrescrita de acuerdo a la subclase del objeto en la lista
            animal.hacerSonido();      
        }
    }
}

package Actividad4_comportamientoSobrescrito;

public class Vaca extends Animal {
    
    
//Constructor    
    public Vaca(String tipo) {
        super(tipo);
    }
    
    
//Sobrescribir el metodo "hacerSonido"
    @Override
    public void hacerSonido() {
        System.out.println("¡Muuuuuuuu!");
    }
}


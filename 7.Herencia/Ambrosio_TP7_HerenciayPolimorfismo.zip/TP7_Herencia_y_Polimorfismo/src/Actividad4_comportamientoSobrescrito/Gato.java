package Actividad4_comportamientoSobrescrito;

public class Gato extends Animal {

//Constructor    
    public Gato(String tipo) {
        super(tipo);
    }

//Sobrescribir el metodo "hacerSonido"
    @Override
    public void hacerSonido() {
        System.out.println("¡Miau Miau!");
    }
}

